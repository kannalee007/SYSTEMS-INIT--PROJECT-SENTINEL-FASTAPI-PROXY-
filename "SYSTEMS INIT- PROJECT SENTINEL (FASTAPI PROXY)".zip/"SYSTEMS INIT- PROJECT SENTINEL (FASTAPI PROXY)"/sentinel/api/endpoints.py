"""FastAPI endpoints for Sentinel security proxy."""
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

from sentinel.services.security import detect_jailbreak, scan_and_redact_pii, scan_outbound_response
from sentinel.services.llm import get_llm_response
from sentinel.utils.logger import log_security_event
from sentinel.config import settings

router = APIRouter()


class PromptRequest(BaseModel):
    prompt: str


@router.get("/")
async def root():
    """Health check and service info."""
    return {
        "service": "Sentinel AI Security Proxy",
        "version": "2.0.0",
        "status": "operational",
        "provider": settings.LLM_PROVIDER,
        "model": settings.OLLAMA_MODEL if settings.LLM_PROVIDER == "ollama" else None,
        "docs": "http://localhost:8000/docs",
        "endpoints": {
            "POST /secure-chat": "Submit prompt for security scanning and LLM processing"
        }
    }


@router.post("/secure-chat")
async def secure_chat(request: PromptRequest):
    """
    Process user prompt through security pipeline:
    1. Jailbreak detection
    2. PII redaction (DLP)
    3. LLM forwarding
    4. Audit logging
    """
    original_prompt = request.prompt
    
    # Log request receipt
    print(f"[SENTINEL ALERT]: Traffic Intercepted - Prompt: {original_prompt[:50]}...")
    log_security_event("REQUEST_RECEIVED", {"prompt_preview": original_prompt[:100]})
    
    # STAGE 1: Jailbreak Defense
    is_jailbreak, matched_pattern = detect_jailbreak(original_prompt)
    if is_jailbreak:
        print(f"[SENTINEL SECURITY]: Jailbreak attack detected! Pattern: {matched_pattern}")
        log_security_event("JAILBREAK_BLOCKED", {
            "pattern_matched": matched_pattern,
            "prompt_preview": original_prompt[:200],
            "action": "BLOCKED"
        })
        raise HTTPException(
            status_code=403,
            detail="Security violation: Prompt injection attempt detected. Request blocked."
        )
    
    # STAGE 2: PII Detection & Redaction (DLP)
    redacted_prompt, entity_types = scan_and_redact_pii(original_prompt)
    
    pii_detected = len(entity_types) > 0
    if pii_detected:
        print(f"[SENTINEL DLP]: PII Detected - {entity_types}")
        log_security_event("PII_REDACTED", {
            "entities": entity_types,
            "original_length": len(original_prompt),
            "redacted_length": len(redacted_prompt),
            "action": "REDACTED"
        })
    else:
        log_security_event("CLEAN_PROMPT", {"action": "PASSED"})
    
    # STAGE 3: LLM Processing
    try:
        raw_llm_response = get_llm_response(redacted_prompt)
        print(f"[SENTINEL]: LLM response received from {settings.LLM_PROVIDER}.")
    except Exception as e:
        print(f"[SENTINEL ERROR]: LLM forwarding failed - {e}")
        raise HTTPException(status_code=502, detail=f"LLM service error: {str(e)}")
    
    # STAGE 4: Outbound DLP - Scan LLM response for hallucinated PII
    llm_response, outbound_entities = scan_outbound_response(raw_llm_response)
    
    if outbound_entities:
        print(f"[SENTINEL OUTBOUND DLP]: Leak prevented! Found {outbound_entities}")
        log_security_event("OUTBOUND_LEAK_PREVENTED", {
            "entities": outbound_entities,
            "response_preview": raw_llm_response[:200],
            "action": "REDACTED"
        })
    
    # Log completion
    log_security_event("REQUEST_COMPLETED", {
        "provider": settings.LLM_PROVIDER,
        "pii_detected": pii_detected,
        "inbound_entities": entity_types,
        "outbound_entities": outbound_entities
    })
    
    return {
        "status": "processed",
        "message": "Prompt processed through security pipeline",
        "provider": settings.LLM_PROVIDER,
        "model": settings.OLLAMA_MODEL if settings.LLM_PROVIDER == "ollama" else None,
        "original_prompt": original_prompt,
        "redacted_prompt": redacted_prompt,
        "pii_detected": pii_detected,
        "entities_found": entity_types,
        "outbound_leak_prevented": len(outbound_entities) > 0,
        "outbound_entities_found": outbound_entities,
        "llm_response": llm_response
    }
