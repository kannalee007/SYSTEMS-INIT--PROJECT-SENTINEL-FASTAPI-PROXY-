"""Security audit logging for compliance and forensics."""
import logging
from datetime import datetime
from typing import Any

# Configure audit logger
audit_logger = logging.getLogger("sentinel_audit")
audit_logger.setLevel(logging.INFO)
audit_logger.propagate = False

def setup_audit_logging(log_file: str = "security_audit.log"):
    """Initialize audit logging to file."""
    handler = logging.FileHandler(log_file)
    handler.setFormatter(logging.Formatter('%(asctime)s | %(levelname)s | %(message)s'))
    audit_logger.addHandler(handler)
    return audit_logger


def log_security_event(event_type: str, details: dict[str, Any]):
    """Log a security event with timestamp for compliance auditing."""
    audit_logger.info(f"EVENT={event_type} | DETAILS={details}")
