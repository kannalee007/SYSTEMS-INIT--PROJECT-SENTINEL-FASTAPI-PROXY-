"""LLM provider integrations: Ollama, Anthropic, and Mock."""
from anthropic import Anthropic
import ollama
from sentinel.config import settings
from sentinel.utils.logger import log_security_event

# Initialize clients
anthropic_client = None

if settings.LLM_PROVIDER == "anthropic":
    if not settings.ANTHROPIC_API_KEY:
        print("[LLM ERROR]: ANTHROPIC_API_KEY not set. Falling back to mock.")
    else:
        anthropic_client = Anthropic(api_key=settings.ANTHROPIC_API_KEY)
        print("[LLM]: Anthropic client initialized.")
elif settings.LLM_PROVIDER == "ollama":
    print(f"[LLM]: Ollama configured (model: {settings.OLLAMA_MODEL})")
    print(f"[LLM]: Ensure Ollama is running: ollama run {settings.OLLAMA_MODEL}")
elif settings.LLM_PROVIDER == "mock":
    print("[LLM]: Mock mode enabled - no external LLM calls.")


def get_llm_response(prompt: str) -> str:
    """
    Forward sanitized prompt to configured LLM provider.
    Returns LLM response text.
    """
    provider = settings.LLM_PROVIDER
    
    if provider == "mock":
        return f"[MOCK LLM RESPONSE] Received sanitized prompt: '{prompt[:100]}...'"
    
    elif provider == "ollama":
        try:
            response = ollama.chat(
                model=settings.OLLAMA_MODEL,
                messages=[{"role": "user", "content": prompt}],
                stream=False
            )
            return response.message.content
        except Exception as e:
            log_security_event("LLM_ERROR", {"provider": "ollama", "error": str(e)})
            raise
    
    elif provider == "anthropic" and anthropic_client:
        try:
            response = anthropic_client.messages.create(
                model="claude-3-5-sonnet-20241022",
                max_tokens=1024,
                messages=[{"role": "user", "content": prompt}]
            )
            return response.content[0].text
        except Exception as e:
            log_security_event("LLM_ERROR", {"provider": "anthropic", "error": str(e)})
            raise
    
    else:
        # Fallback to mock if provider misconfigured
        return f"[MOCK LLM RESPONSE] Provider '{provider}' unavailable. Prompt: '{prompt[:100]}...'"
