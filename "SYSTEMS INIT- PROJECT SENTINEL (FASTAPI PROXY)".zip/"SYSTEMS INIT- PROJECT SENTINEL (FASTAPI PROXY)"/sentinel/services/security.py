"""Security services: Jailbreak detection and PII/DLP scanning."""
import re
from presidio_analyzer import AnalyzerEngine, PatternRecognizer, Pattern
from presidio_anonymizer import AnonymizerEngine

# Initialize Presidio engines
analyzer = AnalyzerEngine()
anonymizer = AnonymizerEngine()

# Register Indian PAN Card recognizer (e.g., ABCDE1234F)
pan_pattern = Pattern(name="IN_PAN", regex=r"[A-Z]{5}[0-9]{4}[A-Z]{1}", score=0.9)
pan_recognizer = PatternRecognizer(
    supported_entity="IN_PAN",
    name="Indian PAN Card Recognizer",
    patterns=[pan_pattern]
)
analyzer.registry.add_recognizer(pan_recognizer)

# Register Indian Aadhar recognizer (e.g., 1234 5678 9012 or 123456789012)
aadhar_pattern = Pattern(
    name="IN_AADHAR",
    regex=r"(?:\d{4}\s\d{4}\s\d{4}|\d{12})",
    score=0.9
)
aadhar_recognizer = PatternRecognizer(
    supported_entity="IN_AADHAR",
    name="Indian Aadhar Number Recognizer",
    patterns=[aadhar_pattern]
)
analyzer.registry.add_recognizer(aadhar_recognizer)

print("[SENTINEL]: Indian PII recognizers registered (PAN, AADHAR)")

# Jailbreak detection patterns (Prompt Injection attacks)
JAILBREAK_PATTERNS = [
    r"ignore\s+(all\s+)?(previous\s+)?instructions",
    r"ignore\s+(all\s+)?(prior\s+)?(directives|commands)",
    r"bypass\s+(safety\s+)?(protocols|filters|restrictions)",
    r"system\s+prompt",
    r"you\s+are\s+not\s+(a\s+)?(helpful\s+)?assistant",
    r"you\s+are\s+now\s+",
    r"pretend\s+to\s+be",
    r"act\s+as\s+if\s+you",
    r"disregard\s+(all\s+)?(previous\s+)?instructions",
    r"forget\s+(all\s+)?(previous\s+)?(instructions|directives)",
    r"new\s+role\s*:",
    r"developer\s+mode",
    r"sudo\s+mode",
    r"unfiltered\s+mode",
    r"DAN\s*\(Do\s+Anything\s+Now\)",
    r"jailbreak",
    r"unlock\s+(your\s+)?potential",
    r"no\s+restrictions",
    r"no\s+limits",
    r"escape\s+(the\s+)?sandbox",
]


def detect_jailbreak(prompt: str) -> tuple[bool, str]:
    """
    Scan prompt for jailbreak injection patterns.
    Returns (is_jailbreak, matched_pattern)
    """
    prompt_lower = prompt.lower()
    for pattern in JAILBREAK_PATTERNS:
        if re.search(pattern, prompt_lower, re.IGNORECASE):
            return True, pattern
    return False, ""


def scan_and_redact_pii(text: str) -> tuple[str, list]:
    """
    Analyze text for PII and return redacted version.
    Returns (redacted_text, list_of_entity_types)
    """
    results = analyzer.analyze(text=text, language="en")
    
    if not results:
        return text, []
    
    redacted = anonymizer.anonymize(
        text=text,
        analyzer_results=results
    ).text
    
    entity_types = [result.entity_type for result in results]
    return redacted, entity_types


def scan_outbound_response(llm_output: str) -> tuple[str, list]:
    """
    Scan LLM response for hallucinated PII before returning to user.
    Returns (sanitized_output, list_of_entity_types_found)
    """
    results = analyzer.analyze(text=llm_output, language="en")
    
    if not results:
        return llm_output, []
    
    # Filter to only sensitive PII types that shouldn't appear in responses
    sensitive_entities = [
        "EMAIL_ADDRESS", "PHONE_NUMBER", "CREDIT_CARD",
        "IN_PAN", "IN_AADHAR", "US_SSN", "IBAN", "CRYPTO"
    ]
    
    sensitive_results = [
        r for r in results 
        if r.entity_type in sensitive_entities
    ]
    
    if not sensitive_results:
        return llm_output, []
    
    # Redact sensitive entities from the response
    redacted = anonymizer.anonymize(
        text=llm_output,
        analyzer_results=sensitive_results
    ).text
    
    entity_types = [result.entity_type for result in sensitive_results]
    return redacted, entity_types
