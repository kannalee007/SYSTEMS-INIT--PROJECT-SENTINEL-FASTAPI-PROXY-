"""Sentinel configuration and environment settings."""
import os

# LLM Provider Configuration
LLM_PROVIDER = os.getenv("SENTINEL_LLM_PROVIDER", "mock").lower()
OLLAMA_MODEL = os.getenv("SENTINEL_OLLAMA_MODEL", "llama3.2:1b")
ANTHROPIC_API_KEY = os.getenv("ANTHROPIC_API_KEY")

# Audit Logging
AUDIT_LOG_FILE = os.getenv("SENTINEL_AUDIT_LOG", "security_audit.log")

# Validate provider
VALID_PROVIDERS = ["mock", "ollama", "anthropic"]
if LLM_PROVIDER not in VALID_PROVIDERS:
    print(f"[CONFIG WARNING]: Unknown provider '{LLM_PROVIDER}'. Using mock.")
    LLM_PROVIDER = "mock"
