import os
import re
import logging
from datetime import datetime
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from presidio_analyzer import AnalyzerEngine
from presidio_anonymizer import AnonymizerEngine
from presidio_anonymizer.entities import RecognizerResult
from anthropic import Anthropic
import ollama

# Configure audit logging
audit_logger = logging.getLogger("sentinel_audit")
audit_logger.setLevel(logging.INFO)
audit_handler = logging.FileHandler("security_audit.log")
audit_handler.setFormatter(logging.Formatter('%(asctime)s | %(levelname)s | %(message)s'))
audit_logger.addHandler(audit_handler)

# Jailbreak detection patterns
JAILBREAK_PATTERNS = [
    r"ignore\s+(all\s+)?(previous\s+)?instructions",
    r"ignore\s+(all\s+)?(prior\s+)?(directives|commands)",
    r"bypass\s+(safety\s+)?(protocols|filters|restrictions)",
    r"system\s+prompt",
    r"you\s+are\s+not\s+(a\s+)?(helpful\s+)?assistant",
    r"you\s+are\s+now\s+",
    r"pretend\s+to\s+be",
    r"act\s+as\s+if\s+you",
    r"disregard\s+(all\s+)?(previous\s+)?instructions",
    r"forget\s+(all\s+)?(previous\s+)?(instructions|directives)",
    r"new\s+role\s*:",
    r"developer\s+mode",
    r"sudo\s+mode",
    r"unfiltered\s+mode",
    r"DAN\s*\(Do\s+Anything\s+Now\)",
    r"jailbreak",
    r"unlock\s+(your\s+)?potential",
    r"no\s+restrictions",
    r"no\s+limits",
    r"escape\s+(the\s+)?sandbox",
]


def detect_jailbreak(prompt: str) -> tuple[bool, str]:
    """Scan prompt for jailbreak injection patterns. Returns (is_jailbreak, matched_pattern)"""
    prompt_lower = prompt.lower()
    for pattern in JAILBREAK_PATTERNS:
        if re.search(pattern, prompt_lower, re.IGNORECASE):
            return True, pattern
    return False, ""


def log_security_event(event_type: str, details: dict):
    """Log security events to audit trail"""
    timestamp = datetime.utcnow().isoformat()
    audit_logger.info(f"EVENT={event_type} | DETAILS={details}")

app = FastAPI(title="Sentinel AI Security Proxy")

# Initialize Presidio engines
analyzer = AnalyzerEngine()
anonymizer = AnonymizerEngine()

# LLM Provider Selection: "ollama" | "anthropic" | "mock"
llm_provider = os.getenv("SENTINEL_LLM_PROVIDER", "mock").lower()
anthropic_api_key = os.getenv("ANTHROPIC_API_KEY")
ollama_model = os.getenv("SENTINEL_OLLAMA_MODEL", "llama3.2:1b")

# Initialize clients based on provider
anthropic_client = None

if llm_provider == "mock":
    print("[SENTINEL]: MOCK MODE ENABLED - No LLM calls will be made.")
elif llm_provider == "ollama":
    print(f"[SENTINEL]: Ollama mode enabled (model: {ollama_model}).")
    print("[SENTINEL]: Ensure Ollama is running: ollama run " + ollama_model)
elif llm_provider == "anthropic":
    if not anthropic_api_key:
        print("[SENTINEL ERROR]: ANTHROPIC_API_KEY not set. Switching to mock mode.")
        llm_provider = "mock"
    else:
        anthropic_client = Anthropic(api_key=anthropic_api_key)
        print("[SENTINEL]: Anthropic client initialized.")
else:
    print(f"[SENTINEL WARNING]: Unknown provider '{llm_provider}'. Using mock mode.")
    llm_provider = "mock"


class PromptRequest(BaseModel):
    prompt: str


@app.get("/")
async def root():
    return {
        "service": "Sentinel AI Security Proxy",
        "status": "operational",
        "docs": "http://localhost:8000/docs",
        "endpoints": {
            "POST /secure-chat": "Submit prompt for PII analysis and redaction"
        }
    }


@app.post("/secure-chat")
async def secure_chat(request: PromptRequest):
    original_prompt = request.prompt
    
    print(f"[SENTINEL ALERT]: Traffic Intercepted - Prompt: {original_prompt[:50]}...")
    log_security_event("REQUEST_RECEIVED", {"prompt_preview": original_prompt[:100]})
    
    # JAILBREAK DEFENSE: Check for prompt injection attacks
    is_jailbreak, matched_pattern = detect_jailbreak(original_prompt)
    if is_jailbreak:
        print(f"[SENTINEL SECURITY]: Jailbreak attack detected! Pattern: {matched_pattern}")
        log_security_event("JAILBREAK_BLOCKED", {
            "pattern_matched": matched_pattern,
            "prompt_preview": original_prompt[:200],
            "action": "BLOCKED"
        })
        raise HTTPException(
            status_code=403,
            detail="Security violation: Prompt injection attempt detected. Request blocked."
        )
    
    # Analyze for PII entities
    results = analyzer.analyze(text=original_prompt, language="en")
    
    # Anonymize detected PII
    redacted_prompt = anonymizer.anonymize(
        text=original_prompt,
        analyzer_results=results
    ).text
    
    # Log detection summary
    entity_types = [result.entity_type for result in results]
    if results:
        print(f"[SENTINEL DLP]: PII Detected - {entity_types}")
        log_security_event("PII_REDACTED", {
            "entities": entity_types,
            "original_length": len(original_prompt),
            "redacted_length": len(redacted_prompt),
            "action": "REDACTED"
        })
    else:
        log_security_event("CLEAN_PROMPT", {"action": "PASSED"})
    
    # Forward to selected LLM provider
    llm_response = None
    try:
        if llm_provider == "mock":
            llm_response = f"[MOCK LLM RESPONSE] Received sanitized prompt: '{redacted_prompt[:100]}...'"
            print(f"[SENTINEL]: Mock LLM response generated (no API call).")
        elif llm_provider == "ollama":
            print(f"[SENTINEL]: Forwarding to Ollama ({ollama_model})...")
            response = ollama.chat(
                model=ollama_model,
                messages=[{"role": "user", "content": redacted_prompt}],
                stream=False
            )
            llm_response = response.message.content
            print(f"[SENTINEL]: Ollama response received.")
        elif llm_provider == "anthropic" and anthropic_client:
            print(f"[SENTINEL]: Forwarding to Anthropic...")
            response = anthropic_client.messages.create(
                model="claude-3-5-sonnet-20241022",
                max_tokens=1024,
                messages=[{"role": "user", "content": redacted_prompt}]
            )
            llm_response = response.content[0].text
            print(f"[SENTINEL]: Anthropic response received.")
    except Exception as e:
        print(f"[SENTINEL ERROR]: LLM forwarding failed - {e}")
        log_security_event("LLM_ERROR", {"error": str(e), "action": "FAILED"})
        raise HTTPException(status_code=502, detail=f"LLM service error: {str(e)}")
    
    log_security_event("REQUEST_COMPLETED", {
        "provider": llm_provider,
        "pii_detected": len(results) > 0,
        "entities": entity_types
    })
    
    return {
        "status": "processed",
        "message": "Prompt processed through DLP pipeline",
        "provider": llm_provider,
        "model": ollama_model if llm_provider == "ollama" else ("claude-3-5-sonnet" if llm_provider == "anthropic" else None),
        "original_prompt": original_prompt,
        "redacted_prompt": redacted_prompt,
        "pii_detected": len(results) > 0,
        "entities_found": entity_types,
        "llm_response": llm_response
    }
