"""
Sentinel AI Security Proxy - Entry Point

Enterprise-grade AI security gateway with:
- Prompt Injection (Jailbreak) Detection
- PII Redaction (Microsoft Presidio DLP)
- Multi-Provider LLM Support (Ollama, Anthropic, Mock)
- Compliance Audit Logging
"""
from fastapi import FastAPI

from sentinel.api.endpoints import router
from sentinel.utils.logger import setup_audit_logging
from sentinel.config import settings

# Initialize audit logging
setup_audit_logging(settings.AUDIT_LOG_FILE)

# Create FastAPI app
app = FastAPI(
    title="Sentinel AI Security Proxy",
    description="Enterprise AI security gateway with DLP and prompt injection protection",
    version="2.0.0"
)

# Include API routes
app.include_router(router)

print("[SENTINEL]: Security proxy initialized and ready.")
print(f"[SENTINEL]: LLM Provider: {settings.LLM_PROVIDER}")
if settings.LLM_PROVIDER == "ollama":
    print(f"[SENTINEL]: Model: {settings.OLLAMA_MODEL}")
